package com.fileshare.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.zip.*;

/**
 * FileShare 2: one raw TCP link per stream (no HTTP), up to 4 parallel streams,
 * 1 MB buffers, Wi-Fi low-latency lock, and automatic nearby-device discovery.
 */
public class MainActivity extends Activity {
    static final int MAGIC = 0x46533032, TCP = 8988, UDP = 8989, BUF = 1 << 20, PICK = 1;
    static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT, WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;
    static final int ACCENT = 0xFF0B57D0, SOFT = 0xFFE8F0FE, CARD = 0xFFF4F6FA, INK = 0xFF1B1F29;

    static class Item { String name; long size; Uri uri; File file; }
    static class Dev { String id, name, ip; int port; long seen; }

    final Handler ui = new Handler(Looper.getMainLooper());
    final String myId = Long.toHexString(System.nanoTime());
    final List<Uri> picked = new ArrayList<>();
    final Map<String, Dev> devs = new ConcurrentHashMap<>();
    final List<File> temps = Collections.synchronizedList(new ArrayList<File>());
    final AtomicLong moved = new AtomicLong();
    final AtomicInteger filesIn = new AtomicInteger();
    volatile boolean cancel, receiving, sending, alive = true;
    volatile long grand;
    ServerSocket server;
    WifiManager.WifiLock wifiLock;
    String selIp, keyShown = "";
    int selPort = TCP, idle;
    long lastBytes, lastTime;
    double smooth;

    LinearLayout sendCard, recvCard, devBox;
    TextView picks, addr, status, speed;
    EditText manual;
    CheckBox zip;
    ProgressBar bar;
    Button tSend, tRecv, start, sendBtn;

    final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.elapsedRealtime(), b = moved.get();
            if (lastTime != 0 && now > lastTime) {
                double mbs = Math.max(0, b - lastBytes) / 1048576.0 / ((now - lastTime) / 1000.0);
                idle = (b == lastBytes) ? idle + 1 : 0;
                smooth = idle > 2 ? 0 : smooth * 0.5 + mbs * 0.5;
            }
            lastBytes = b;
            lastTime = now;
            speed.setText(String.format(Locale.US, "%.1f MB/s", smooth) + (b > 0 ? "  \u00B7  " + fmt(b) : ""));
            bar.setProgress(grand > 0 ? (int) Math.min(1000, b * 1000 / grand) : 0);
            refreshDevices();
            if (alive) ui.postDelayed(this, 500);
        }
    };

    // ---------- UI ----------

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "FileShare");
            wifiLock.setReferenceCounted(false);
        } catch (Exception ignored) {
        }

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = col();
        root.setPadding(dp(18), dp(36), dp(18), dp(24));
        sv.addView(root);

        TextView title = label("FileShare", 32, true);
        title.setTextColor(ACCENT);
        root.addView(title);
        root.addView(label("Fast file transfer over Wi-Fi. Keep this screen open on both phones.", 14, false));

        LinearLayout tabs = new LinearLayout(this);
        tSend = btn("Send", true);
        tRecv = btn("Receive", false);
        tabs.addView(tSend, weight());
        tabs.addView(tRecv, weight());
        root.addView(tabs, margin(12));

        sendCard = card(root);
        Button choose = btn("Choose files", false);
        picks = label("No files chosen", 14, false);
        devBox = col();
        manual = new EditText(this);
        manual.setHint("Or type an address, e.g. 192.168.1.5:8988");
        manual.setSingleLine(true);
        zip = new CheckBox(this);
        zip.setText("Pack into one ZIP (no compression)");
        sendBtn = btn("Send now", true);
        sendCard.addView(choose);
        sendCard.addView(picks);
        sendCard.addView(label("Nearby devices", 14, true));
        sendCard.addView(devBox);
        sendCard.addView(manual);
        sendCard.addView(zip);
        sendCard.addView(sendBtn, margin(8));

        recvCard = card(root);
        start = btn("Start receiving", true);
        addr = label("Tap Start receiving. This phone will then appear on the sender's screen.", 16, false);
        addr.setTypeface(Typeface.MONOSPACE);
        recvCard.addView(start);
        recvCard.addView(addr);
        recvCard.addView(label("Files are saved in Downloads/FileShare.", 13, false));

        LinearLayout st = card(root);
        speed = label("0.0 MB/s", 28, true);
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setProgressTintList(ColorStateList.valueOf(ACCENT));
        status = label("Ready.", 14, false);
        st.addView(speed);
        st.addView(bar);
        st.addView(status);
        setContentView(sv);

        tSend.setOnClickListener(v -> tab(true));
        tRecv.setOnClickListener(v -> tab(false));
        choose.setOnClickListener(v -> {
            Intent in = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            in.addCategory(Intent.CATEGORY_OPENABLE);
            in.setType("*/*");
            in.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(in, PICK);
        });
        sendBtn.setOnClickListener(v -> send());
        start.setOnClickListener(v -> toggleReceive());
        tab(true);
        listenForDevices();
        ui.post(tick);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req != PICK || res != RESULT_OK || d == null) return;
        picked.clear();
        if (d.getClipData() != null) {
            for (int i = 0; i < d.getClipData().getItemCount(); i++) {
                picked.add(d.getClipData().getItemAt(i).getUri());
            }
        } else if (d.getData() != null) {
            picked.add(d.getData());
        }
        picks.setText(picked.size() + " file(s) chosen");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        alive = false;
        cancel = true;
        sending = false;
        stopReceive();
        for (File f : new ArrayList<File>(temps)) f.delete();
    }

    void tab(boolean send) {
        sendCard.setVisibility(send ? View.VISIBLE : View.GONE);
        recvCard.setVisibility(send ? View.GONE : View.VISIBLE);
        style(tSend, send);
        style(tRecv, !send);
    }

    void refreshDevices() {
        long now = SystemClock.elapsedRealtime();
        List<Dev> l = new ArrayList<>();
        for (Dev d : devs.values()) {
            if (now - d.seen > 4000) devs.remove(d.id);
            else l.add(d);
        }
        Collections.sort(l, (x, y) -> x.name.compareTo(y.name));
        StringBuilder k = new StringBuilder(String.valueOf(selIp));
        for (Dev d : l) k.append(d.id);
        if (k.toString().equals(keyShown)) return;
        keyShown = k.toString();
        devBox.removeAllViews();
        if (l.isEmpty()) {
            devBox.addView(label("None yet. On the other phone, open Receive and tap Start receiving.", 13, false));
            return;
        }
        for (final Dev d : l) {
            Button b = btn(d.name + "  " + d.ip, d.ip.equals(selIp));
            b.setOnClickListener(v -> {
                selIp = d.ip;
                selPort = d.port;
                manual.setText("");
            });
            devBox.addView(b, margin(6));
        }
    }

    // ---------- Receive ----------

    void toggleReceive() {
        if (receiving) {
            stopReceive();
            return;
        }
        final ServerSocket ss = listen();
        if (ss == null) {
            say("Cannot start receiving. Close other apps that use the network and try again.");
            return;
        }
        server = ss;
        receiving = true;
        grand = 0;
        moved.set(0);
        filesIn.set(0);
        syncLock();
        start.setText("Stop receiving");
        addr.setText("Visible as \"" + Build.MODEL + "\"\nAddress: " + localIp() + ":" + ss.getLocalPort());
        say("Waiting for a sender...");
        final int port = ss.getLocalPort();
        new Thread(() -> advertise(port)).start();
        new Thread(() -> {
            while (receiving && !ss.isClosed()) {
                try {
                    final Socket c = ss.accept();
                    new Thread(() -> handle(c)).start();
                } catch (IOException e) {
                    break;
                }
            }
        }).start();
    }

    void stopReceive() {
        receiving = false;
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
        }
        server = null;
        syncLock();
        if (start != null) start.setText("Start receiving");
        if (addr != null) addr.setText("Receiving stopped.");
    }

    ServerSocket listen() {
        for (int p : new int[]{TCP, 0}) {
            try {
                ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(p));
                return ss;
            } catch (IOException ignored) {
            }
        }
        return null;
    }

    void handle(Socket sock) {
        try (Socket s = sock) {
            s.setSoTimeout(30000);
            DataInputStream in = new DataInputStream(s.getInputStream());
            if (in.readInt() != MAGIC) return;
            byte[] buf = new byte[BUF];
            int count = 0;
            while (true) {
                int len = in.readInt();
                if (len == 0) break;
                if (len < 0 || len > 4096) throw new IOException("Bad header");
                byte[] nb = new byte[len];
                in.readFully(nb);
                long size = in.readLong();
                if (size < 0) throw new IOException("Bad size");
                save(in, clean(new String(nb, StandardCharsets.UTF_8)), size, buf);
                count++;
            }
            s.getOutputStream().write(1);
            s.getOutputStream().flush();
            filesIn.addAndGet(count);
            say("Received " + filesIn.get() + " file(s). Saved in Downloads/FileShare.");
        } catch (Exception e) {
            say("Receiving failed: " + msg(e));
        }
    }

    /** Writes into a hidden "pending" file, so half-received files never show up in Downloads. */
    void save(InputStream in, String name, long size, byte[] buf) throws IOException {
        ContentResolver r = getContentResolver();
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
        cv.put(MediaStore.Downloads.RELATIVE_PATH, "Download/FileShare");
        cv.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri u = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        if (u == null) throw new IOException("Cannot create a file in Downloads");
        try {
            try (OutputStream o = r.openOutputStream(u)) {
                long left = size;
                while (left > 0) {
                    int n = in.read(buf, 0, (int) Math.min(buf.length, left));
                    if (n < 0) throw new EOFException("Connection lost");
                    o.write(buf, 0, n);
                    left -= n;
                    moved.addAndGet(n);
                }
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Downloads.IS_PENDING, 0);
            r.update(u, done, null, null);
        } catch (IOException | RuntimeException e) {
            try {
                r.delete(u, null, null);
            } catch (Exception ignored) {
            }
            throw e;
        }
    }

    // ---------- Discovery ----------

    void advertise(int port) {
        try (DatagramSocket ds = new DatagramSocket()) {
            ds.setBroadcast(true);
            byte[] m = ("FS2|" + myId + "|" + Build.MODEL.replace('|', ' ') + "|" + port).getBytes(StandardCharsets.UTF_8);
            while (receiving) {
                for (InetAddress b : broadcasts()) {
                    try {
                        ds.send(new DatagramPacket(m, m.length, b, UDP));
                    } catch (IOException ignored) {
                    }
                }
                Thread.sleep(1000);
            }
        } catch (Exception ignored) {
        }
    }

    List<InetAddress> broadcasts() {
        List<InetAddress> l = new ArrayList<>();
        try {
            l.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) {
        }
        try {
            for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!n.isUp() || n.isLoopback()) continue;
                for (InterfaceAddress a : n.getInterfaceAddresses()) {
                    if (a.getBroadcast() != null) l.add(a.getBroadcast());
                }
            }
        } catch (Exception ignored) {
        }
        return l;
    }

    void listenForDevices() {
        new Thread(() -> {
            try (DatagramSocket ds = new DatagramSocket((SocketAddress) null)) {
                ds.setReuseAddress(true);
                ds.bind(new InetSocketAddress(UDP));
                ds.setSoTimeout(1000);
                byte[] b = new byte[512];
                while (alive) {
                    try {
                        DatagramPacket p = new DatagramPacket(b, b.length);
                        ds.receive(p);
                        String[] f = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8).split("\\|");
                        if (f.length == 4 && f[0].equals("FS2") && !f[1].equals(myId)) {
                            Dev d = new Dev();
                            d.id = f[1];
                            d.name = f[2];
                            d.ip = p.getAddress().getHostAddress();
                            d.port = Integer.parseInt(f[3]);
                            d.seen = SystemClock.elapsedRealtime();
                            devs.put(d.id, d);
                        }
                    } catch (SocketTimeoutException | NumberFormatException ignored) {
                    } catch (IOException e) {
                        Thread.sleep(500);
                    }
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    String localIp() {
        String any = null;
        try {
            for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                String nm = n.getName();
                if (!n.isUp() || n.isLoopback() || nm.startsWith("rmnet") || nm.startsWith("ccmni")
                        || nm.startsWith("tun") || nm.startsWith("v4-") || nm.startsWith("dummy")) continue;
                for (InetAddress a : Collections.list(n.getInetAddresses())) {
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        if (nm.startsWith("wlan") || nm.startsWith("ap") || nm.startsWith("swlan")) return a.getHostAddress();
                        if (any == null) any = a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return any != null ? any : "(connect to Wi-Fi first)";
    }

    // ---------- Send ----------

    void send() {
        if (sending) return;
        if (picked.isEmpty()) {
            say("Choose at least one file first.");
            return;
        }
        String host = selIp;
        int port = selPort;
        String m = manual.getText().toString().trim().replace("http://", "").replace("/", "");
        if (!m.isEmpty()) {
            int c = m.lastIndexOf(':');
            host = c > 0 ? m.substring(0, c) : m;
            port = TCP;
            if (c > 0) {
                try {
                    port = Integer.parseInt(m.substring(c + 1));
                } catch (NumberFormatException e) {
                    say("The number after ':' must be a port, like 8988.");
                    return;
                }
            }
        }
        if (host == null) {
            say("Pick a nearby device, or type the receiver's address.");
            return;
        }
        final String h = host;
        final int p = port;
        final boolean asZip = zip.isChecked();
        final List<Uri> uris = new ArrayList<>(picked);
        sending = true;
        cancel = false;
        grand = 0;
        moved.set(0);
        syncLock();
        sendBtn.setEnabled(false);
        sendBtn.setText("Sending...");
        new Thread(() -> transfer(h, p, uris, asZip)).start();
    }

    void transfer(String host, int port, List<Uri> uris, boolean asZip) {
        AtomicReference<String> err = new AtomicReference<>();
        try {
            say("Preparing...");
            List<Item> items = new ArrayList<>();
            for (Uri u : uris) {
                Item it = new Item();
                it.uri = u;
                it.name = clean(nameOf(u));
                it.size = sizeOf(u);
                if (it.size < 0) { // size unknown: copy to cache once to learn it
                    File f = tempFile();
                    try (InputStream in = open(it); OutputStream o = new FileOutputStream(f)) {
                        copy(in, o);
                    }
                    it.file = f;
                    it.size = f.length();
                }
                items.add(it);
            }
            if (asZip) {
                Item z = new Item();
                z.name = "FileShare.zip";
                z.file = tempFile();
                zipTo(z.file, items);
                z.size = z.file.length();
                items.clear();
                items.add(z);
            }
            long total = 0;
            for (Item it : items) total += it.size;
            grand = total;
            final ConcurrentLinkedQueue<Item> q = new ConcurrentLinkedQueue<>(items);
            int n = Math.min(4, items.size());
            Thread[] ts = new Thread[n];
            say("Sending " + items.size() + " file(s) on " + n + " stream(s)...");
            for (int i = 0; i < n; i++) {
                ts[i] = new Thread(() -> {
                    try {
                        push(host, port, q);
                    } catch (Exception e) {
                        err.compareAndSet(null, msg(e));
                        cancel = true;
                    }
                });
                ts[i].start();
            }
            for (Thread t : ts) t.join();
            if (err.get() != null) throw new IOException(err.get());
            say("Done. Sent " + (asZip ? "1 ZIP file" : items.size() + " file(s)") + " (" + fmt(moved.get()) + ").");
        } catch (Exception e) {
            say("Sending failed: " + msg(e) + "\nCheck that both phones are on the same Wi-Fi and the other one shows Stop receiving.");
        } finally {
            for (File f : new ArrayList<File>(temps)) f.delete();
            temps.clear();
            sending = false;
            ui.post(() -> {
                sendBtn.setEnabled(true);
                sendBtn.setText("Send now");
                syncLock();
            });
        }
    }

    /** One connection: pulls files from the shared queue until it is empty. */
    void push(String host, int port, Queue<Item> q) throws Exception {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), 8000);
            s.setSoTimeout(120000);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream(), 65536));
            out.writeInt(MAGIC);
            byte[] buf = new byte[BUF];
            Item it;
            while ((it = q.poll()) != null) {
                byte[] nb = it.name.getBytes(StandardCharsets.UTF_8);
                out.writeInt(nb.length);
                out.write(nb);
                out.writeLong(it.size);
                try (InputStream in = open(it)) {
                    long left = it.size;
                    while (left > 0) {
                        if (cancel) throw new IOException("Cancelled");
                        int n = in.read(buf, 0, (int) Math.min(buf.length, left));
                        if (n < 0) throw new EOFException("A file changed while sending: " + it.name);
                        out.write(buf, 0, n);
                        left -= n;
                        moved.addAndGet(n);
                    }
                }
            }
            out.writeInt(0);
            out.flush();
            if (s.getInputStream().read() != 1) throw new IOException("The receiver did not confirm. Some files may be missing.");
        }
    }

    void zipTo(File dest, List<Item> items) throws IOException {
        Set<String> used = new HashSet<>();
        try (ZipOutputStream zo = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(dest), BUF))) {
            zo.setLevel(Deflater.NO_COMPRESSION);
            for (Item it : items) {
                String n = it.name;
                for (int k = 1; !used.add(n); k++) n = k + "_" + it.name;
                zo.putNextEntry(new ZipEntry(n));
                try (InputStream in = open(it)) {
                    copy(in, zo);
                }
                zo.closeEntry();
            }
        }
    }

    // ---------- Helpers ----------

    File tempFile() throws IOException {
        File f = File.createTempFile("fs", ".tmp", getCacheDir());
        temps.add(f);
        return f;
    }

    InputStream open(Item it) throws IOException {
        if (it.file != null) return new FileInputStream(it.file);
        InputStream s = getContentResolver().openInputStream(it.uri);
        if (s == null) throw new FileNotFoundException("Cannot open " + it.name);
        return s;
    }

    long sizeOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getLong(0);
        } catch (Exception ignored) {
        }
        return -1;
    }

    String nameOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getString(0);
        } catch (Exception ignored) {
        }
        String p = u.getLastPathSegment();
        return p == null ? "file" : p;
    }

    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[BUF];
        int n;
        while ((n = in.read(b)) != -1) out.write(b, 0, n);
    }

    static String clean(String n) {
        n = n.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (n.length() > 120) n = n.substring(n.length() - 120);
        return (n.isEmpty() || n.equals(".") || n.equals("..")) ? "file" : n;
    }

    static String fmt(long b) {
        if (b < 1 << 20) return String.format(Locale.US, "%.0f KB", b / 1024.0);
        if (b < 1L << 30) return String.format(Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(Locale.US, "%.2f GB", b / 1073741824.0);
    }

    static String msg(Exception e) {
        return e.getMessage() != null ? e.getMessage() : e.toString();
    }

    void say(String s) {
        ui.post(() -> status.setText(s));
    }

    void syncLock() {
        try {
            if (wifiLock == null) return;
            if (receiving || sending) {
                if (!wifiLock.isHeld()) wifiLock.acquire();
            } else if (wifiLock.isHeld()) {
                wifiLock.release();
            }
        } catch (Exception ignored) {
        }
    }

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    LinearLayout col() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout card(LinearLayout root) {
        LinearLayout l = col();
        l.setBackground(round(CARD, 20));
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        root.addView(l, margin(12));
        return l;
    }

    LinearLayout.LayoutParams margin(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(MATCH, WRAP);
        p.topMargin = dp(top);
        return p;
    }

    LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, 1);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    TextView label(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(INK);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    Button btn(String s, boolean on) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setStateListAnimator(null);
        style(b, on);
        b.setPadding(dp(16), dp(12), dp(16), dp(12));
        return b;
    }

    void style(Button b, boolean on) {
        b.setTextColor(on ? Color.WHITE : ACCENT);
        b.setBackground(round(on ? ACCENT : SOFT, 28));
    }
}
